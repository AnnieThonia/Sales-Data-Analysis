select * from production.brands;
select * from production.categories;
select * from production.products;
select * from production.stocks;


select * from sales.customers;
select * from sales.order_items;
select * from sales.orders;
select * from sales.staffs;
select * from sales.stores;

/*

 select e.order_id,e.quantity, e.list_price,e.discount
 ,a.customer_id, a.order_date, a.store_id, a.staff_id
,concat(b.first_name , ' ' , b.last_name)customers, b.street, b.state, b.zip_code  
,concat(c.first_name , ' ' , c.last_name)sales_rep 
, d.store_name,d.city
, f.product_name, f.brand_id, f.category_id, f.model_year
, g.category_name
, h.brand_name
from sales.order_items e left join sales.orders a on e.order_id= a.order_id
left join  sales.customers b on a.customer_id = b.customer_id
left join  sales.staffs c on a.staff_id = c.staff_id
left join  sales.stores d on a.store_id = d.store_id
left join production.products f on e.product_id = f.product_id
left join production.categories g on f.category_id = g.category_id
left join production.brands h on f.brand_id = h.brand_id
 */

select count(a.order_id) from (
select e.order_id,e.quantity total_unit, ((e.quantity* e.list_price)- e.discount)revenue
,a.order_date
,concat(b.first_name , ' ' , b.last_name)customer, b.street, d.city, b.zip_code , b.state 
,concat(c.first_name , ' ' , c.last_name)sales_rep 
, d.store_name
, f.product_name, f.model_year, h.brand_name
, g.category_name
from sales.order_items e left join sales.orders a on e.order_id= a.order_id
left join  sales.customers b on a.customer_id = b.customer_id
left join  sales.staffs c on a.staff_id = c.staff_id
left join  sales.stores d on a.store_id = d.store_id
left join production.products f on e.product_id = f.product_id
left join production.categories g on f.category_id = g.category_id
left join production.brands h on f.brand_id = h.brand_id
 )a
 
 
 